Fast Kalman Filter for Attitude Estimation By S. Guo and J. Wu. e-mail: jin_wu_uestc@hotmail.com

The current citation could be: S. Guo, J. Wu, Z. Wang, J. Qian, "Novel MARG-Sensor Orientation Estimation Algorithm Using Fast Kalman Filter", Journal of Sensors, 2017.
